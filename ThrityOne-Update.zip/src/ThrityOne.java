/*
 * Group Project - Game 31
 * Group 8 
 * Members: Alexzandrea Olson, Cameron Rottier, Kyu Seung Sim, Jennifer Witt
 * 
 * Sep, 16 2020
 * 
 */

import java.util.*;


public class ThrityOne {

	int deck[] = new int[52]; // save deck list.
	String[] suitList = {"c","s","h","d"}; // Club, Spade, Heart, Diamond
	String[] numberList = {"2","3","4","5","6","7","8","9","J","Q","K","A"};

	final int MAX_SCORE = 31;              // 31 Game max score
	final int MAX_CARD = 3;				   // Player can't get over 3 cards
	final int DEFAULT_WAGER  = 10;         // Each game Wager amount.
	final int DEFAULT_WALLET = 500;        // This is default money when first time play game. It can change to life system.
	
	int player_wallet = DEFAULT_WALLET;
	int player_wager = DEFAULT_WAGER;
	

	
	public void UpdateWallet(int update_amount) {

		if(player_wallet <= 0) {
			System.out.println("Out of Money! Game Over!");
		} else {
			player_wallet += update_amount;
			System.out.println("Wallet Updated!");
			System.out.print("Your Wallet amount is: " + player_wallet);
			System.out.println();
		}
		
	}
	
	public void Deck() {
		// Making Deck fast.
		for(int i = 0; i < 52; i++) {
			deck[i] = i;
		}
	}
	
	public void Suffle(int index) {
		Random suffle = new Random();
		
		// suffles my deck 1000 times, i can change number instead 1000
		for(int i = 0; i < 1000; i++) { 
			int rNumber = suffle.nextInt(52); // Range 1 ~ 52
			int temp;
			temp = deck[index];
			deck[index] = deck[rNumber];
			deck[rNumber] = temp;
			
			deck[index] = rNumber;
		}
	}
	
	public void DealCard(int PlayDeck[], int index) {
		
		int deckIndex = index;
		int playDeckIndex = index;		
		
		Suffle(index);
		PlayDeck[playDeckIndex] = deck[deckIndex];
		//System.out.println("INDEX: " + index);
		//System.out.println("TEXT: " + deck[deckIndex]);
	}
	
	public void StayButton() {
		
	}
	
	public void SwapButton() {
		
	}
	
	public void KnockButton() {
		
	}
	
	public void Winner(int dealer_score, int player_score) {
		
		if(player_score > dealer_score) {
			System.out.println("This Game Player Win");
			UpdateWallet(player_wager);			
		} else if(player_score == dealer_score) {
			System.out.println("This Game Draw");

		} else if(player_score < dealer_score) {
			System.out.println("This Game Delaer Win");
			UpdateWallet(-player_wager);	
		}
	}
	
	public void Score() {	
	}
	
	public void Game() {	
	}
	
	public void ThirtyOneStart() {
		
		int playerDeck[] = {0, 0, 0}; 
		int dealerDeck[] = {0, 0, 0}; 
		int tableDeck[] = {0, 0, 0};
		
		if(player_wager < 1) {
			System.out.println("BID TOO LOW: Wager now $" + DEFAULT_WAGER);
			player_wager = DEFAULT_WAGER;
		} else if(player_wager > player_wallet) {
			System.out.println("BID TOO HIGH: Wager now $" + player_wallet);
			player_wager = player_wallet;
		}
		
		
		// Deal Player Deck
		DealCard(playerDeck, 0);
		DealCard(playerDeck, 1);
		DealCard(playerDeck, 2);

		
		// Deal Dealer Deck
		DealCard(dealerDeck, 0);
		DealCard(dealerDeck, 1);
		DealCard(dealerDeck, 2);

		
		// Deal Table Deck
		DealCard(tableDeck, 0);
		DealCard(tableDeck, 1);
		DealCard(tableDeck, 2);


	    // Print out Player Deck
        System.out.println("[Player] Card");
        for(int i=0; i<3; i++) {
            System.out.println("Card Shape: " + suitList[playerDeck[i] / numberList.length]);
            System.out.println("Card Number: " + numberList[playerDeck[i] % numberList.length]);
            System.out.println("--------------");
        }

        System.out.println("[Table] Card");
        for(int i=0; i<3; i++) {
            System.out.println("Card Shape: " + suitList[tableDeck[i] / numberList.length]);
            System.out.println("Card Number: " + numberList[tableDeck[i] % numberList.length]);
            System.out.println("--------------");
        }
        
	}

}
