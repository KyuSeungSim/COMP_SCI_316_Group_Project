/*
 * Group Project - Game 31
 * Group 8 
 * Members: Alexzandrea Olson, Cameron Rottier, Kyu Seung Sim, Jennifer Witt
 * 
 * Sep, 16 2020
 * 
 */

import java.util.*;


public class ThrityOne {

	
	String[] suitList = {"c","s","h","d"}; // Club, Spade, Heart, Diamond
	String[] numberList = {"2","3","4","5","6","7","8","9","J","Q","K","A"};
	
	final int MAX_SCORE = 31;              // 31 Game max score
	final int MAX_CARD = 3;				   // Player can't get over 3 cards
	final int DEFAULT_WAGER  = 10;         // Each game Wager amount.
	final int DEFAULT_WALLET = 500;        // This is default money when first time play game. It can change to life system.
	
	int player_wallet = DEFAULT_WALLET;
	int player_wager = DEFAULT_WAGER;
	
	
	public void UpdateWallet(int update_amount) {

		if(player_wallet <= 0) {
			System.out.println("Out of Money! Game Over!");
		} else {
			player_wallet += update_amount;
			System.out.println("Wallet Updated!");
			System.out.print("Your Wallet amount is: " + player_wallet);
			System.out.println();
		}
		
	}
	
	public void Deck() {
		String[] cards;
		
	}
	
	public void Suffle() {
		
	}
	
	public void DealCard() {
		
	}
	
	public void StayButton() {
		
	}
	
	public void SwapButton() {
		
	}
	
	public void KnockButton() {
		
	}
	
	public void Winner(int dealer_score, int player_score) {
		
		if(player_score > dealer_score) {
			System.out.println("This Game Player Win");
			UpdateWallet(player_wager);			
		} else if(player_score == dealer_score) {
			System.out.println("This Game Draw");

		} else if(player_score < dealer_score) {
			System.out.println("This Game Delaer Win");
			UpdateWallet(-player_wager);	
		}
	}
	
	public void Score() {
		
	}
	
	public void Game() {
		
		String[] dealer_hand;
		String[] player_hand;	
		
		int dealer_score = 0;
		int player_score = 0;
		
	}
	
	public void ThirtyOneStart() {
		
		if(player_wager < 1) {
			System.out.println("BID TOO LOW: Wager now $" + DEFAULT_WAGER);
			player_wager = DEFAULT_WAGER;
		} else if(player_wager > player_wallet) {
			System.out.println("BID TOO HIGH: Wager now $" + player_wallet);
			player_wager = player_wallet;
		}
		
		/* 
		 * ** Deal 3 cards each player and center section.
		 * DealCard(dealer)
		 * DealCard(dealer)
		 * DealCard(dealer)
		 * 
		 * DealCard(player)
		 * DealCard(player)
		 * DealCard(player)
		 * 
		 * DealCard(center)
		 * DealCard(center)
		 * DealCard(center)
		 * 
		 */
		
		System.out.println("Welcome to 31 Game");
		
		
		System.out.println("TEST");
	}
	
	
	
	
}
